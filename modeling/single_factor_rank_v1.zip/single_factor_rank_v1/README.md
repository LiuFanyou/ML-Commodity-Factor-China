# Single Factor Rank V1

对每个候选字段单独做横截面排序信号，并做滚动样本外多空评价。不做多因子加权或回归。

候选字段默认取 `ml_feature_registry.csv` 中 `usage_type` 为 `predictor` / `orthogonalized_predictor` 的字段（约 17 个）。

## 运行

在项目根目录（含 `src/` 与 `training_handoff/` 的 `--main`）执行：

```bash
# Windows
set PYTHONPATH=src
py -m factor_modeling.single_factor_rank --config modeling/single_factor_rank_v1/config.json

# 或使用本目录入口脚本
py modeling/single_factor_rank_v1/run.py

# 冒烟：只跑前 3 个候选字段
py -m factor_modeling.single_factor_rank --config modeling/single_factor_rank_v1/config.json --limit 3
```

## 模型逻辑摘要

1. 标签：下一交易日开盘至收盘收益 `future_return_1d`；`target_cs_rank_1d` 仅作可选质量指标，不参与选因子。
2. 分数：`signed_signal = factor * direction`，再按日做 `cs_rank_centered` 映射到 `[-1, 1]`。
3. 方向：优先用因子目录 `expected_direction`；若为 0，仅在该折训练窗内用日均 RankIC 符号冻结方向。
4. 策略：按 `prediction` 排序，最高 20% 做多、最低 20% 做空；多空各 0.5，总敞口 1，收盘平仓。
5. 评价：日均 RankIC、IC 胜率、毛/净（1/3/5bp）Sharpe；输出因子排行榜。
6. 验证：三年训练、下一年测试，覆盖 2018—2024；训练窗末端 purge 1 个交易日。

## 主要输出

- `single_factor_rank_report.md`
- `outputs/oos_predictions.csv.gz`
- `outputs/strategy_daily_returns.csv`
- `outputs/factor_metrics.csv`
- `outputs/fold_metrics.csv`
- `outputs/yearly_factor_metrics.csv`
- `outputs/daily_prediction_ic.csv`
- `outputs/leaderboard.csv`
- `outputs/run_summary.json`

## 源码位置

- `src/factor_modeling/single_factor_rank.py`
