# 单因子排序模型测试报告

> 本报告由真实开发数据自动生成；模型为**单因子横截面排序**，不含多因子加权或回归系数。
> 2025 不参与因子选择、方向选择或主评价。

## 模型与标签选择

- 模型：每个候选字段单独作为横截面排序信号；不做多因子回归、不估计组合系数。
- 分数变换：`cs_rank_centered`（同日横截面中心化排名，映射到[-1,1]）。
- 原始收益标签：`future_return_1d`（因子形成后的下一交易日开盘至收盘可交易收益）。
- 对照目标：`target_cs_rank_1d`（同日横截面中心化收益排名）；仅作可选对照，不参与选因子。
- IC 与策略收益一律相对 `future_return_1d` 计算。
- 外层验证：三年训练、下一年测试，覆盖 2018—2024；训练窗末端 purge 1 个交易日。
- 方向：读取因子目录 `expected_direction`；若为 0，仅在该折训练窗内用日均 RankIC 符号选向并冻结。

## 策略定义

- 每个信号日按 `prediction` 升序排序，最低 20% 做空、最高 20% 做多。
- 多头权重合计 0.5，空头权重合计 0.5；净敞口 0，总敞口 1；组内等权。
- 次日开盘建仓、当日收盘平仓；往返换手按 2 计算。
- 净收益 = 毛收益 − 2 × one_way_cost_bps / 10000；仅报告单边 1/3/5 基点敏感性。
- 当日有效品种数 < 10 则跳过组合；IC 要求当日有效样本 ≥ 5 且两侧有变异。

## 候选因子/字段范围

- usage_type 过滤：['predictor', 'orthogonalized_predictor']
- 开发样本截止：2024-12-31

| usage_type | 字段数 |
| --- | --- |
| orthogonalized_predictor | 2 |
| predictor | 15 |

目录期望方向分布（+1 / -1 / 0）：

| expected_direction | 字段数 |
| --- | --- |
| 0 | 3 |
| 1 | 14 |

## 总体样本外预测结果

| 指标 | 结果 |
| --- | --- |
| 样本外年份 | 2018—2024 |
| 候选字段数 | 17 |
| score_transform | cs_rank_centered |
| 全部因子日均RankIC中位数 | 0.0098 |
| 全部因子日均Pearson IC中位数 | 0.0059 |

全体因子分布摘要：

| 指标 | 结果 |
| --- | --- |
| 候选因子数 | 17 |
| RankIC均值(中位数) | 0.0098 |
| RankIC均值(均值) | 0.0094 |
| 毛Sharpe中位数 | 0.3250 |
| 毛Sharpe为正的因子占比 | 0.8235 |
| RankIC胜率>=0.5的因子占比 | 0.8235 |

- Top1（按日均RankIC）：`term_structure_slope__cs_robust_z`，RankIC=0.0258，胜率=0.5453，毛年化=0.0815，毛Sharpe=0.8919，净3bp Sharpe=-0.7630。

## 各因子策略绩效（逐因子，非中位数）

下表对**每一个**候选因子单独给出样本外毛收益与成本敏感性指标（按 RankIC 排序）。完整数值另见 `outputs/factor_strategy_metrics.csv`。

| feature_name | source_factor | usage_type | rank_ic_mean | rank_ic_hit_rate | gross_annual_return | gross_annual_volatility | gross_sharpe | gross_max_drawdown | gross_total_return | gross_hit_rate | net_1bps_annual_return | net_1bps_sharpe | net_3bps_annual_return | net_3bps_sharpe | net_5bps_annual_return | net_5bps_sharpe | strategy_days | years_evaluated | years_gross_sharpe_positive |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| term_structure_slope__cs_robust_z | 期限结构斜率 | predictor | 0.0258 | 0.5453 | 0.0815 | 0.0914 | 0.8919 | -0.1104 | 0.6835 | 0.5330 | 0.0311 | 0.3403 | -0.0697 | -0.7630 | -0.1705 | -1.8663 | 1698 | 7 | 6 |
| reversal_5__cs_robust_z | 短期反转 | predictor | 0.0254 | 0.5259 | 0.0695 | 0.0988 | 0.7029 | -0.1566 | 0.5453 | 0.5165 | 0.0191 | 0.1930 | -0.0817 | -0.8269 | -0.1825 | -1.8468 | 1698 | 7 | 6 |
| carry__cs_robust_z | Carry | predictor | 0.0230 | 0.5489 | 0.0848 | 0.0803 | 1.0556 | -0.1242 | 0.7321 | 0.5353 | 0.0344 | 0.4279 | -0.0664 | -0.8274 | -0.1672 | -2.0827 | 1698 | 7 | 6 |
| interaction__tsmom_20__oi_surprise_20__cs_robust_z | 因子交互 | predictor | 0.0159 | 0.5218 | 0.0524 | 0.0696 | 0.7532 | -0.0815 | 0.4003 | 0.5153 | 0.0020 | 0.0286 | -0.0988 | -1.4206 | -0.1996 | -2.8699 | 1698 | 7 | 6 |
| oi_surprise_60__cs_robust_z | 持仓意外 | predictor | 0.0114 | 0.5318 | 0.0335 | 0.0677 | 0.4942 | -0.1300 | 0.2338 | 0.5194 | -0.0169 | -0.2500 | -0.1177 | -1.7384 | -0.2185 | -3.2268 | 1698 | 7 | 5 |
| reversal_20__cs_robust_z | 短期反转 | predictor | 0.0114 | 0.5171 | 0.0328 | 0.1010 | 0.3250 | -0.1553 | 0.2054 | 0.5065 | -0.0176 | -0.1741 | -0.1184 | -1.1724 | -0.2192 | -2.1706 | 1698 | 7 | 4 |
| carry_change_60__cs_robust_z | Carry变化 | predictor | 0.0112 | 0.5183 | 0.0414 | 0.0702 | 0.5895 | -0.1668 | 0.2999 | 0.5259 | -0.0090 | -0.1283 | -0.1098 | -1.5639 | -0.2106 | -2.9995 | 1698 | 7 | 5 |
| term_structure_momentum_60__cs_robust_z | 期限结构动量 | predictor | 0.0106 | 0.5236 | 0.0339 | 0.0796 | 0.4256 | -0.1667 | 0.2300 | 0.5347 | -0.0165 | -0.2072 | -0.1173 | -1.4728 | -0.2181 | -2.7384 | 1698 | 7 | 4 |
| basis_momentum_5__cs_robust_z | 基差动量 | predictor | 0.0098 | 0.5206 | 0.0442 | 0.0716 | 0.6180 | -0.1100 | 0.3241 | 0.5135 | -0.0062 | -0.0863 | -0.1070 | -1.4948 | -0.2078 | -2.9033 | 1698 | 7 | 6 |
| basis_momentum_60__cs_robust_z | 基差动量 | predictor | 0.0074 | 0.5071 | 0.0217 | 0.0696 | 0.3125 | -0.1635 | 0.1391 | 0.5188 | -0.0287 | -0.4119 | -0.1295 | -1.8607 | -0.2303 | -3.3096 | 1698 | 7 | 5 |
| tsmom_120__cs_robust_z | 时间序列动量 | predictor | 0.0059 | 0.5247 | 0.0138 | 0.0880 | 0.1573 | -0.2117 | 0.0695 | 0.5112 | -0.0366 | -0.4157 | -0.1374 | -1.5617 | -0.2382 | -2.7077 | 1698 | 7 | 5 |
| seasonality_3y_month__cs_robust_z | 季节性 | predictor | 0.0046 | 0.5124 | 0.0207 | 0.0798 | 0.2596 | -0.2044 | 0.1254 | 0.5088 | -0.0297 | -0.3722 | -0.1305 | -1.6359 | -0.2313 | -2.8995 | 1698 | 7 | 5 |
| carry_change_20__cs_robust_z | Carry变化 | predictor | 0.0037 | 0.5106 | 0.0059 | 0.0695 | 0.0844 | -0.1563 | 0.0236 | 0.4947 | -0.0445 | -0.6403 | -0.1453 | -2.0897 | -0.2461 | -3.5391 | 1698 | 7 | 5 |
| basis_momentum_20__cs_robust_z | 基差动量 | predictor | 0.0031 | 0.5053 | -0.0077 | 0.0691 | -0.1110 | -0.1661 | -0.0654 | 0.4853 | -0.0581 | -0.8408 | -0.1589 | -2.3005 | -0.2597 | -3.7602 | 1698 | 7 | 3 |
| orth__carry_change_20__vs__basis_momentum_20 | Carry变化 | orthogonalized_predictor | 0.0021 | 0.4935 | -0.0073 | 0.0655 | -0.1113 | -0.1552 | -0.0616 | 0.5024 | -0.0577 | -0.8811 | -0.1585 | -2.4207 | -0.2593 | -3.9603 | 1698 | 7 | 3 |
| orth__basis_momentum_60__vs__carry_change_60 | 基差动量 | orthogonalized_predictor | -0.0039 | 0.4947 | 0.0028 | 0.0625 | 0.0442 | -0.1783 | 0.0055 | 0.5077 | -0.0476 | -0.7623 | -0.1484 | -2.3753 | -0.2492 | -3.9882 | 1698 | 7 | 2 |
| curve_curvature__cs_robust_z | 期限结构曲率 | predictor | -0.0079 | 0.4870 | -0.0336 | 0.0698 | -0.4811 | -0.3039 | -0.2154 | 0.4859 | -0.0840 | -1.2033 | -0.1848 | -2.6477 | -0.2856 | -4.0922 | 1698 | 7 | 2 |

## 分年度滚动结果

分年度 RankIC、毛 Sharpe、净 3bp Sharpe（按因子 × 测试年）：

| feature_name | test_year | rank_ic_mean | rank_ic_hit_rate | gross_sharpe | net_3bps_sharpe | gross_annual_return | strategy_days | applied_direction | direction_source |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| basis_momentum_20__cs_robust_z | 2018 | 0.0009 | 0.5021 | -0.3165 | -2.9409 | -0.0182 | 243 | 1 | catalog |
| basis_momentum_20__cs_robust_z | 2019 | -0.0090 | 0.4672 | -1.3552 | -4.0721 | -0.0754 | 244 | 1 | catalog |
| basis_momentum_20__cs_robust_z | 2020 | 0.0048 | 0.5062 | -0.1887 | -2.6643 | -0.0115 | 243 | 1 | catalog |
| basis_momentum_20__cs_robust_z | 2021 | -0.0062 | 0.5062 | 0.2151 | -1.3819 | 0.0204 | 243 | 1 | catalog |
| basis_momentum_20__cs_robust_z | 2022 | 0.0066 | 0.5413 | 0.0227 | -1.9146 | 0.0018 | 242 | 1 | catalog |
| basis_momentum_20__cs_robust_z | 2023 | 0.0187 | 0.5124 | 0.9956 | -1.2624 | 0.0667 | 242 | 1 | catalog |
| basis_momentum_20__cs_robust_z | 2024 | 0.0062 | 0.5021 | -0.6008 | -3.0636 | -0.0369 | 241 | 1 | catalog |
| basis_momentum_5__cs_robust_z | 2018 | 0.0277 | 0.5350 | 1.6465 | -1.1404 | 0.0893 | 243 | 1 | catalog |
| basis_momentum_5__cs_robust_z | 2019 | 0.0079 | 0.4836 | 0.5382 | -2.0468 | 0.0315 | 244 | 1 | catalog |
| basis_momentum_5__cs_robust_z | 2020 | 0.0215 | 0.5679 | 0.9899 | -1.3175 | 0.0649 | 243 | 1 | catalog |
| basis_momentum_5__cs_robust_z | 2021 | -0.0038 | 0.4979 | 0.3255 | -1.1515 | 0.0333 | 243 | 1 | catalog |
| basis_momentum_5__cs_robust_z | 2022 | -0.0100 | 0.4959 | -0.2513 | -2.0164 | -0.0215 | 242 | 1 | catalog |
| basis_momentum_5__cs_robust_z | 2023 | 0.0101 | 0.5289 | 0.6545 | -1.7956 | 0.0404 | 242 | 1 | catalog |
| basis_momentum_5__cs_robust_z | 2024 | 0.0153 | 0.5353 | 1.1852 | -1.3136 | 0.0717 | 241 | 1 | catalog |
| basis_momentum_60__cs_robust_z | 2018 | 0.0250 | 0.5432 | 1.5734 | -1.1498 | 0.0874 | 243 | 1 | catalog |
| basis_momentum_60__cs_robust_z | 2019 | -0.0247 | 0.4385 | -2.4454 | -4.9487 | -0.1477 | 244 | 1 | catalog |
| basis_momentum_60__cs_robust_z | 2020 | 0.0169 | 0.5309 | 1.7433 | -0.4774 | 0.1187 | 243 | 1 | catalog |
| basis_momentum_60__cs_robust_z | 2021 | -0.0100 | 0.4486 | -0.4866 | -2.1908 | -0.0432 | 243 | 1 | catalog |
| basis_momentum_60__cs_robust_z | 2022 | 0.0059 | 0.5289 | 0.8451 | -0.9352 | 0.0718 | 242 | 1 | catalog |
| basis_momentum_60__cs_robust_z | 2023 | 0.0148 | 0.5165 | 0.2588 | -2.2171 | 0.0158 | 242 | 1 | catalog |
| basis_momentum_60__cs_robust_z | 2024 | 0.0245 | 0.5436 | 0.8403 | -1.6722 | 0.0506 | 241 | 1 | catalog |
| carry__cs_robust_z | 2018 | 0.0293 | 0.5267 | 1.8494 | -0.3948 | 0.1246 | 243 | 1 | catalog |
| carry__cs_robust_z | 2019 | 0.0085 | 0.5779 | -0.5908 | -2.9104 | -0.0385 | 244 | 1 | catalog |
| carry__cs_robust_z | 2020 | 0.0604 | 0.6049 | 2.5775 | 0.7569 | 0.2141 | 243 | 1 | catalog |
| carry__cs_robust_z | 2021 | -0.0037 | 0.4733 | 0.1127 | -1.3313 | 0.0118 | 243 | 1 | catalog |
| carry__cs_robust_z | 2022 | 0.0134 | 0.5620 | 1.4048 | -0.2274 | 0.1301 | 242 | 1 | catalog |
| carry__cs_robust_z | 2023 | 0.0003 | 0.5041 | 0.3008 | -1.9238 | 0.0204 | 242 | 1 | catalog |
| carry__cs_robust_z | 2024 | 0.0530 | 0.5934 | 1.8153 | -0.2701 | 0.1316 | 241 | 1 | catalog |
| carry_change_20__cs_robust_z | 2018 | -0.0056 | 0.4979 | 0.0524 | -2.4934 | 0.0031 | 243 | 1 | catalog |
| carry_change_20__cs_robust_z | 2019 | -0.0037 | 0.5082 | -1.6711 | -4.2406 | -0.0983 | 244 | 1 | catalog |
| carry_change_20__cs_robust_z | 2020 | 0.0105 | 0.5226 | 0.0624 | -2.4171 | 0.0038 | 243 | 1 | catalog |
| carry_change_20__cs_robust_z | 2021 | -0.0071 | 0.5062 | 0.7001 | -0.9313 | 0.0649 | 243 | 1 | catalog |
| carry_change_20__cs_robust_z | 2022 | 0.0109 | 0.5537 | 0.8165 | -1.1291 | 0.0635 | 242 | 1 | catalog |
| carry_change_20__cs_robust_z | 2023 | 0.0120 | 0.4752 | 0.4518 | -1.7065 | 0.0316 | 242 | 1 | catalog |
| carry_change_20__cs_robust_z | 2024 | 0.0093 | 0.5104 | -0.4461 | -2.9476 | -0.0270 | 241 | 1 | catalog |
| carry_change_60__cs_robust_z | 2018 | 0.0244 | 0.5473 | 1.2546 | -1.4791 | 0.0694 | 243 | 1 | catalog |
| carry_change_60__cs_robust_z | 2019 | -0.0238 | 0.4344 | -2.4220 | -5.0006 | -0.1420 | 244 | 1 | catalog |
| carry_change_60__cs_robust_z | 2020 | 0.0228 | 0.5432 | 1.5879 | -0.5380 | 0.1129 | 243 | 1 | catalog |
| carry_change_60__cs_robust_z | 2021 | -0.0079 | 0.4527 | -0.2600 | -1.9005 | -0.0240 | 243 | 1 | catalog |
| carry_change_60__cs_robust_z | 2022 | 0.0113 | 0.5207 | 1.5160 | -0.3212 | 0.1248 | 242 | 1 | catalog |
| carry_change_60__cs_robust_z | 2023 | 0.0221 | 0.5496 | 0.9131 | -1.5976 | 0.0550 | 242 | 1 | catalog |
| carry_change_60__cs_robust_z | 2024 | 0.0299 | 0.5809 | 1.5112 | -0.8886 | 0.0952 | 241 | 1 | catalog |
| curve_curvature__cs_robust_z | 2018 | 0.0177 | 0.5514 | 1.2159 | -1.4587 | 0.0687 | 243 | -1 | train_rank_ic |
| curve_curvature__cs_robust_z | 2019 | -0.0101 | 0.5164 | -1.4146 | -4.0760 | -0.0804 | 244 | -1 | train_rank_ic |
| curve_curvature__cs_robust_z | 2020 | 0.0158 | 0.5267 | 0.9635 | -1.6636 | 0.0555 | 243 | -1 | train_rank_ic |
| curve_curvature__cs_robust_z | 2021 | -0.0090 | 0.4527 | -0.2391 | -1.8917 | -0.0219 | 243 | -1 | train_rank_ic |
| curve_curvature__cs_robust_z | 2022 | -0.0131 | 0.4463 | -0.4028 | -2.2382 | -0.0332 | 242 | 1 | train_rank_ic |
| curve_curvature__cs_robust_z | 2023 | -0.0172 | 0.4752 | -0.6205 | -2.8841 | -0.0415 | 242 | -1 | train_rank_ic |
| curve_curvature__cs_robust_z | 2024 | -0.0397 | 0.4398 | -2.6763 | -4.8831 | -0.1834 | 241 | 1 | train_rank_ic |
| interaction__tsmom_20__oi_surprise_20__cs_robust_z | 2018 | 0.0063 | 0.4856 | -0.0306 | -2.6213 | -0.0018 | 243 | -1 | train_rank_ic |
| interaction__tsmom_20__oi_surprise_20__cs_robust_z | 2019 | 0.0215 | 0.5205 | 0.9505 | -1.4728 | 0.0593 | 244 | -1 | train_rank_ic |
| interaction__tsmom_20__oi_surprise_20__cs_robust_z | 2020 | 0.0200 | 0.5350 | 0.4377 | -1.8715 | 0.0287 | 243 | -1 | train_rank_ic |
| interaction__tsmom_20__oi_surprise_20__cs_robust_z | 2021 | 0.0141 | 0.5226 | 1.2983 | -0.3121 | 0.1219 | 243 | -1 | train_rank_ic |
| interaction__tsmom_20__oi_surprise_20__cs_robust_z | 2022 | 0.0157 | 0.5041 | 0.7759 | -1.0449 | 0.0644 | 242 | -1 | train_rank_ic |
| interaction__tsmom_20__oi_surprise_20__cs_robust_z | 2023 | 0.0038 | 0.5496 | 0.2943 | -2.2108 | 0.0178 | 242 | -1 | train_rank_ic |
| interaction__tsmom_20__oi_surprise_20__cs_robust_z | 2024 | 0.0296 | 0.5353 | 1.3983 | -1.3642 | 0.0765 | 241 | -1 | train_rank_ic |
| oi_surprise_60__cs_robust_z | 2018 | 0.0184 | 0.5062 | 0.9135 | -1.7284 | 0.0523 | 243 | -1 | train_rank_ic |
| oi_surprise_60__cs_robust_z | 2019 | 0.0112 | 0.5451 | -0.7125 | -3.3340 | -0.0411 | 244 | -1 | train_rank_ic |
| oi_surprise_60__cs_robust_z | 2020 | -0.0057 | 0.4897 | -0.6078 | -3.2123 | -0.0353 | 243 | -1 | train_rank_ic |
| oi_surprise_60__cs_robust_z | 2021 | 0.0256 | 0.5720 | 1.2199 | -0.4349 | 0.1115 | 243 | -1 | train_rank_ic |
| oi_surprise_60__cs_robust_z | 2022 | 0.0155 | 0.5537 | 0.9099 | -0.8773 | 0.0770 | 242 | -1 | train_rank_ic |
| oi_surprise_60__cs_robust_z | 2023 | 0.0121 | 0.5331 | 1.1073 | -1.4428 | 0.0657 | 242 | -1 | train_rank_ic |
| oi_surprise_60__cs_robust_z | 2024 | 0.0028 | 0.5228 | 0.0836 | -2.6133 | 0.0047 | 241 | -1 | train_rank_ic |
| orth__basis_momentum_60__vs__carry_change_60 | 2018 | 0.0023 | 0.4938 | 1.3983 | -1.3377 | 0.0773 | 243 | 1 | catalog |
| orth__basis_momentum_60__vs__carry_change_60 | 2019 | 0.0076 | 0.5123 | -0.7342 | -3.7330 | -0.0370 | 244 | 1 | catalog |
| orth__basis_momentum_60__vs__carry_change_60 | 2020 | -0.0107 | 0.4897 | -0.6729 | -3.3044 | -0.0387 | 243 | 1 | catalog |
| orth__basis_momentum_60__vs__carry_change_60 | 2021 | -0.0011 | 0.5185 | -0.0110 | -1.9191 | -0.0009 | 243 | 1 | catalog |
| orth__basis_momentum_60__vs__carry_change_60 | 2022 | -0.0233 | 0.4380 | -1.2031 | -3.3578 | -0.0844 | 242 | 1 | catalog |
| orth__basis_momentum_60__vs__carry_change_60 | 2023 | 0.0119 | 0.5331 | 1.7382 | -0.7737 | 0.1046 | 242 | 1 | catalog |
| orth__basis_momentum_60__vs__carry_change_60 | 2024 | -0.0141 | 0.4772 | -0.0232 | -2.5398 | -0.0014 | 241 | 1 | catalog |
| orth__carry_change_20__vs__basis_momentum_20 | 2018 | -0.0186 | 0.4198 | -0.8961 | -3.4987 | -0.0521 | 243 | 1 | catalog |
| orth__carry_change_20__vs__basis_momentum_20 | 2019 | -0.0022 | 0.4672 | -0.9853 | -3.9160 | -0.0508 | 244 | 1 | catalog |
| orth__carry_change_20__vs__basis_momentum_20 | 2020 | 0.0186 | 0.5432 | -0.3976 | -2.7748 | -0.0253 | 243 | 1 | catalog |
| orth__carry_change_20__vs__basis_momentum_20 | 2021 | -0.0036 | 0.5185 | 0.3100 | -1.3963 | 0.0275 | 243 | 1 | catalog |
| orth__carry_change_20__vs__basis_momentum_20 | 2022 | 0.0129 | 0.5289 | 0.8485 | -1.1871 | 0.0630 | 242 | 1 | catalog |
| orth__carry_change_20__vs__basis_momentum_20 | 2023 | -0.0013 | 0.4876 | -0.5424 | -3.0704 | -0.0324 | 242 | 1 | catalog |
| orth__carry_change_20__vs__basis_momentum_20 | 2024 | 0.0089 | 0.4896 | 0.3573 | -2.3873 | 0.0197 | 241 | 1 | catalog |
| reversal_20__cs_robust_z | 2018 | 0.0212 | 0.5391 | -0.1494 | -1.9834 | -0.0123 | 243 | 1 | catalog |
| reversal_20__cs_robust_z | 2019 | 0.0052 | 0.5164 | -0.3118 | -2.1233 | -0.0260 | 244 | 1 | catalog |
| reversal_20__cs_robust_z | 2020 | -0.0158 | 0.4650 | -0.2999 | -1.8852 | -0.0286 | 243 | 1 | catalog |
| reversal_20__cs_robust_z | 2021 | 0.0425 | 0.5638 | 0.6651 | -0.3939 | 0.0950 | 243 | 1 | catalog |
| reversal_20__cs_robust_z | 2022 | 0.0107 | 0.5124 | 1.1239 | -0.2672 | 0.1222 | 242 | 1 | catalog |
| reversal_20__cs_robust_z | 2023 | 0.0141 | 0.5496 | 0.0142 | -1.6055 | 0.0013 | 242 | 1 | catalog |
| reversal_20__cs_robust_z | 2024 | 0.0020 | 0.4730 | 0.8985 | -0.8192 | 0.0791 | 241 | 1 | catalog |
| reversal_5__cs_robust_z | 2018 | 0.0327 | 0.5514 | 0.2301 | -1.7155 | 0.0179 | 243 | 1 | catalog |
| reversal_5__cs_robust_z | 2019 | 0.0214 | 0.4959 | -0.0409 | -1.9026 | -0.0033 | 244 | 1 | catalog |
| reversal_5__cs_robust_z | 2020 | 0.0354 | 0.5309 | 1.6138 | 0.0141 | 0.1525 | 243 | 1 | catalog |
| reversal_5__cs_robust_z | 2021 | 0.0414 | 0.5185 | 0.8801 | -0.2595 | 0.1168 | 243 | 1 | catalog |
| reversal_5__cs_robust_z | 2022 | 0.0187 | 0.5413 | 1.0440 | -0.2195 | 0.1249 | 242 | 1 | catalog |
| reversal_5__cs_robust_z | 2023 | 0.0014 | 0.4959 | 0.1381 | -1.7611 | 0.0110 | 242 | 1 | catalog |
| reversal_5__cs_robust_z | 2024 | 0.0268 | 0.5477 | 0.7157 | -0.9048 | 0.0668 | 241 | 1 | catalog |
| seasonality_3y_month__cs_robust_z | 2018 | 0.0011 | 0.4897 | 0.8875 | -1.3944 | 0.0588 | 243 | 1 | catalog |
| seasonality_3y_month__cs_robust_z | 2019 | 0.0160 | 0.5369 | 0.6283 | -1.5629 | 0.0434 | 244 | 1 | catalog |
| seasonality_3y_month__cs_robust_z | 2020 | 0.0155 | 0.5556 | 1.0227 | -1.1253 | 0.0720 | 243 | 1 | catalog |
| seasonality_3y_month__cs_robust_z | 2021 | 0.0081 | 0.5103 | 0.5870 | -0.9806 | 0.0566 | 243 | 1 | catalog |
| seasonality_3y_month__cs_robust_z | 2022 | 0.0225 | 0.5372 | 1.2471 | -0.4831 | 0.1090 | 242 | 1 | catalog |
| seasonality_3y_month__cs_robust_z | 2023 | -0.0088 | 0.4793 | -0.9210 | -2.8694 | -0.0715 | 242 | 1 | catalog |
| seasonality_3y_month__cs_robust_z | 2024 | -0.0227 | 0.4772 | -1.4411 | -3.1897 | -0.1246 | 241 | 1 | catalog |
| term_structure_momentum_60__cs_robust_z | 2018 | 0.0248 | 0.6008 | 2.4854 | -0.1470 | 0.1428 | 243 | 1 | catalog |
| term_structure_momentum_60__cs_robust_z | 2019 | 0.0146 | 0.5164 | 0.8450 | -1.8980 | 0.0466 | 244 | 1 | catalog |
| term_structure_momentum_60__cs_robust_z | 2020 | 0.0167 | 0.5144 | -0.3613 | -2.1414 | -0.0307 | 243 | 1 | catalog |
| term_structure_momentum_60__cs_robust_z | 2021 | -0.0175 | 0.4650 | -0.6905 | -1.9816 | -0.0809 | 243 | 1 | catalog |
| term_structure_momentum_60__cs_robust_z | 2022 | 0.0083 | 0.5331 | 1.1811 | -0.5697 | 0.1020 | 242 | 1 | catalog |
| term_structure_momentum_60__cs_robust_z | 2023 | 0.0164 | 0.5083 | 1.0497 | -1.2526 | 0.0689 | 242 | 1 | catalog |
| term_structure_momentum_60__cs_robust_z | 2024 | 0.0110 | 0.5270 | -0.1561 | -2.2176 | -0.0114 | 241 | 1 | catalog |
| term_structure_slope__cs_robust_z | 2018 | 0.0269 | 0.5267 | 1.0632 | -0.9394 | 0.0803 | 243 | 1 | catalog |
| term_structure_slope__cs_robust_z | 2019 | 0.0262 | 0.5246 | 1.6452 | -0.4910 | 0.1164 | 244 | 1 | catalog |
| term_structure_slope__cs_robust_z | 2020 | 0.0636 | 0.6091 | 2.5109 | 1.0878 | 0.2668 | 243 | 1 | catalog |
| term_structure_slope__cs_robust_z | 2021 | 0.0053 | 0.5432 | -0.2079 | -1.4891 | -0.0245 | 243 | 1 | catalog |
| term_structure_slope__cs_robust_z | 2022 | 0.0360 | 0.5661 | 1.1236 | -0.5058 | 0.1043 | 242 | 1 | catalog |
| term_structure_slope__cs_robust_z | 2023 | 0.0024 | 0.5207 | 0.1432 | -1.7842 | 0.0112 | 242 | 1 | catalog |
| term_structure_slope__cs_robust_z | 2024 | 0.0200 | 0.5270 | 0.1716 | -1.5496 | 0.0151 | 241 | 1 | catalog |
| tsmom_120__cs_robust_z | 2018 | -0.0046 | 0.5226 | 0.7165 | -1.6080 | 0.0466 | 243 | 1 | catalog |
| tsmom_120__cs_robust_z | 2019 | 0.0034 | 0.5492 | 0.6637 | -1.5288 | 0.0458 | 244 | 1 | catalog |
| tsmom_120__cs_robust_z | 2020 | 0.0335 | 0.5556 | 1.2248 | -0.3342 | 0.1188 | 243 | 1 | catalog |
| tsmom_120__cs_robust_z | 2021 | -0.0114 | 0.4897 | -0.8932 | -2.2241 | -0.1015 | 243 | 1 | catalog |
| tsmom_120__cs_robust_z | 2022 | 0.0141 | 0.5248 | 0.0553 | -1.4355 | 0.0056 | 242 | 1 | catalog |
| tsmom_120__cs_robust_z | 2023 | -0.0168 | 0.4669 | -0.8858 | -2.7265 | -0.0728 | 242 | 1 | catalog |
| tsmom_120__cs_robust_z | 2024 | 0.0232 | 0.5643 | 0.7061 | -1.2663 | 0.0541 | 241 | 1 | catalog |

## 因子排行榜（RankIC 与 Sharpe）

主排序键：日均 RankIC ↓，RankIC 胜率 ↓，毛 Sharpe ↓，覆盖率 ↓。

### RankIC 榜 Top 20

| rank | feature_name | source_factor | usage_type | catalog_direction | rank_ic_mean | rank_ic_hit_rate | rank_icir | gross_sharpe | net_3bps_sharpe | strategy_days | strategy_coverage |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | term_structure_slope__cs_robust_z | 期限结构斜率 | predictor | 1 | 0.0258 | 0.5453 | 0.0937 | 0.8919 | -0.7630 | 1698 | 1.0000 |
| 2 | reversal_5__cs_robust_z | 短期反转 | predictor | 1 | 0.0254 | 0.5259 | 0.0892 | 0.7029 | -0.8269 | 1698 | 1.0000 |
| 3 | carry__cs_robust_z | Carry | predictor | 1 | 0.0230 | 0.5489 | 0.0944 | 1.0556 | -0.8274 | 1698 | 1.0000 |
| 4 | interaction__tsmom_20__oi_surprise_20__cs_robust_z | 因子交互 | predictor | 0 | 0.0159 | 0.5218 | 0.0739 | 0.7532 | -1.4206 | 1698 | 1.0000 |
| 5 | oi_surprise_60__cs_robust_z | 持仓意外 | predictor | 0 | 0.0114 | 0.5318 | 0.0546 | 0.4942 | -1.7384 | 1698 | 1.0000 |
| 6 | reversal_20__cs_robust_z | 短期反转 | predictor | 1 | 0.0114 | 0.5171 | 0.0388 | 0.3250 | -1.1724 | 1698 | 1.0000 |
| 7 | carry_change_60__cs_robust_z | Carry变化 | predictor | 1 | 0.0112 | 0.5183 | 0.0544 | 0.5895 | -1.5639 | 1698 | 1.0000 |
| 8 | term_structure_momentum_60__cs_robust_z | 期限结构动量 | predictor | 1 | 0.0106 | 0.5236 | 0.0463 | 0.4256 | -1.4728 | 1698 | 1.0000 |
| 9 | basis_momentum_5__cs_robust_z | 基差动量 | predictor | 1 | 0.0098 | 0.5206 | 0.0473 | 0.6180 | -1.4948 | 1698 | 1.0000 |
| 10 | basis_momentum_60__cs_robust_z | 基差动量 | predictor | 1 | 0.0074 | 0.5071 | 0.0362 | 0.3125 | -1.8607 | 1698 | 1.0000 |
| 11 | tsmom_120__cs_robust_z | 时间序列动量 | predictor | 1 | 0.0059 | 0.5247 | 0.0215 | 0.1573 | -1.5617 | 1698 | 1.0000 |
| 12 | seasonality_3y_month__cs_robust_z | 季节性 | predictor | 1 | 0.0046 | 0.5124 | 0.0176 | 0.2596 | -1.6359 | 1698 | 1.0000 |
| 13 | carry_change_20__cs_robust_z | Carry变化 | predictor | 1 | 0.0037 | 0.5106 | 0.0185 | 0.0844 | -2.0897 | 1698 | 1.0000 |
| 14 | basis_momentum_20__cs_robust_z | 基差动量 | predictor | 1 | 0.0031 | 0.5053 | 0.0157 | -0.1110 | -2.3005 | 1698 | 1.0000 |
| 15 | orth__carry_change_20__vs__basis_momentum_20 | Carry变化 | orthogonalized_predictor | 1 | 0.0021 | 0.4935 | 0.0105 | -0.1113 | -2.4207 | 1698 | 1.0000 |
| 16 | orth__basis_momentum_60__vs__carry_change_60 | 基差动量 | orthogonalized_predictor | 1 | -0.0039 | 0.4947 | -0.0200 | 0.0442 | -2.3753 | 1698 | 1.0000 |
| 17 | curve_curvature__cs_robust_z | 期限结构曲率 | predictor | 0 | -0.0079 | 0.4870 | -0.0389 | -0.4811 | -2.6477 | 1698 | 1.0000 |

### 毛 Sharpe 榜 Top 20

| rank | feature_name | source_factor | usage_type | catalog_direction | rank_ic_mean | rank_ic_hit_rate | rank_icir | gross_sharpe | net_3bps_sharpe | strategy_days | strategy_coverage |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 3 | carry__cs_robust_z | Carry | predictor | 1 | 0.0230 | 0.5489 | 0.0944 | 1.0556 | -0.8274 | 1698 | 1.0000 |
| 1 | term_structure_slope__cs_robust_z | 期限结构斜率 | predictor | 1 | 0.0258 | 0.5453 | 0.0937 | 0.8919 | -0.7630 | 1698 | 1.0000 |
| 4 | interaction__tsmom_20__oi_surprise_20__cs_robust_z | 因子交互 | predictor | 0 | 0.0159 | 0.5218 | 0.0739 | 0.7532 | -1.4206 | 1698 | 1.0000 |
| 2 | reversal_5__cs_robust_z | 短期反转 | predictor | 1 | 0.0254 | 0.5259 | 0.0892 | 0.7029 | -0.8269 | 1698 | 1.0000 |
| 9 | basis_momentum_5__cs_robust_z | 基差动量 | predictor | 1 | 0.0098 | 0.5206 | 0.0473 | 0.6180 | -1.4948 | 1698 | 1.0000 |
| 7 | carry_change_60__cs_robust_z | Carry变化 | predictor | 1 | 0.0112 | 0.5183 | 0.0544 | 0.5895 | -1.5639 | 1698 | 1.0000 |
| 5 | oi_surprise_60__cs_robust_z | 持仓意外 | predictor | 0 | 0.0114 | 0.5318 | 0.0546 | 0.4942 | -1.7384 | 1698 | 1.0000 |
| 8 | term_structure_momentum_60__cs_robust_z | 期限结构动量 | predictor | 1 | 0.0106 | 0.5236 | 0.0463 | 0.4256 | -1.4728 | 1698 | 1.0000 |
| 6 | reversal_20__cs_robust_z | 短期反转 | predictor | 1 | 0.0114 | 0.5171 | 0.0388 | 0.3250 | -1.1724 | 1698 | 1.0000 |
| 10 | basis_momentum_60__cs_robust_z | 基差动量 | predictor | 1 | 0.0074 | 0.5071 | 0.0362 | 0.3125 | -1.8607 | 1698 | 1.0000 |
| 12 | seasonality_3y_month__cs_robust_z | 季节性 | predictor | 1 | 0.0046 | 0.5124 | 0.0176 | 0.2596 | -1.6359 | 1698 | 1.0000 |
| 11 | tsmom_120__cs_robust_z | 时间序列动量 | predictor | 1 | 0.0059 | 0.5247 | 0.0215 | 0.1573 | -1.5617 | 1698 | 1.0000 |
| 13 | carry_change_20__cs_robust_z | Carry变化 | predictor | 1 | 0.0037 | 0.5106 | 0.0185 | 0.0844 | -2.0897 | 1698 | 1.0000 |
| 16 | orth__basis_momentum_60__vs__carry_change_60 | 基差动量 | orthogonalized_predictor | 1 | -0.0039 | 0.4947 | -0.0200 | 0.0442 | -2.3753 | 1698 | 1.0000 |
| 14 | basis_momentum_20__cs_robust_z | 基差动量 | predictor | 1 | 0.0031 | 0.5053 | 0.0157 | -0.1110 | -2.3005 | 1698 | 1.0000 |
| 15 | orth__carry_change_20__vs__basis_momentum_20 | Carry变化 | orthogonalized_predictor | 1 | 0.0021 | 0.4935 | 0.0105 | -0.1113 | -2.4207 | 1698 | 1.0000 |
| 17 | curve_curvature__cs_robust_z | 期限结构曲率 | predictor | 0 | -0.0079 | 0.4870 | -0.0389 | -0.4811 | -2.6477 | 1698 | 1.0000 |

### 不稳定或偏弱因子（如实披露）

以下因子 RankIC 胜率 < 0.5 或毛 Sharpe < 0，稳定性存疑，不宜单独作为强结论：

| feature_name | rank_ic_mean | rank_ic_hit_rate | gross_sharpe | net_3bps_sharpe |
| --- | --- | --- | --- | --- |
| basis_momentum_20__cs_robust_z | 0.0031 | 0.5053 | -0.1110 | -2.3005 |
| orth__carry_change_20__vs__basis_momentum_20 | 0.0021 | 0.4935 | -0.1113 | -2.4207 |
| orth__basis_momentum_60__vs__carry_change_60 | -0.0039 | 0.4947 | 0.0442 | -2.3753 |
| curve_curvature__cs_robust_z | -0.0079 | 0.4870 | -0.4811 | -2.6477 |

## 使用边界

1. 点时：因子在 T 日收盘后形成，信号仅可用于 T+1 开盘交易；切分、方向选择与评价均未使用测试段。
2. 本模型是单字段排序，**不是**多因子加权或回归拟合结果。
3. 成本仅为单边 1/3/5 基点敏感性，不得解读为已核验的真实手续费或冲击成本。
4. 2025 未参与主评价；若另做补充样本外，须单独配置与目录，并标注为补充证据、非封存测试。
5. 未核验合约乘数、涨跌停、成交容量与真实交易成本，结果仅属研究回测。
